(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_04186324._.js",
  "static/chunks/app_habits_page_tsx_10e31edb._.js"
],
    source: "dynamic"
});
