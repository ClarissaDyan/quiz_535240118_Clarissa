(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a6f5cdf2._.js",
  "static/chunks/app_habits_[id]_page_tsx_8f8fbae8._.js"
],
    source: "dynamic"
});
