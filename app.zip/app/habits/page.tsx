'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Container, Row, Col, Card, Button, Form, Alert, Modal } from 'react-bootstrap';

interface Habit {
  id: number;
  name: string;
  description: string;
  createdAt: string;
  completedDays: number;
}

export default function HabitsPage() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [newHabitName, setNewHabitName] = useState('');
  const [newHabitDescription, setNewHabitDescription] = useState('');
  const [loading, setLoading] = useState(false);
  
  // State untuk Edit
  const [showEditModal, setShowEditModal] = useState(false);
  const [editHabit, setEditHabit] = useState<Habit | null>(null);
  const [editName, setEditName] = useState('');
  const [editDescription, setEditDescription] = useState('');

  // Fetch habits dari API
  const fetchHabits = async () => {
    try {
      const response = await fetch('/api/habits');
      const data = await response.json();
      setHabits(data);
    } catch (error) {
      console.error('Error fetching habits:', error);
      alert('Gagal mengambil data habits');
    }
  };

  useEffect(() => {
    fetchHabits();
  }, []);

  // CREATE - Tambah habit baru
  const addHabit = async () => {
    if (newHabitName.trim() === '') {
      alert('Nama habit tidak boleh kosong!');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/habits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newHabitName,
          description: newHabitDescription,
        })
      });

      if (response.ok) {
        setNewHabitName('');
        setNewHabitDescription('');
        fetchHabits(); // Refresh list
        alert('✅ Habit berhasil ditambahkan!');
      } else {
        alert('❌ Gagal menambahkan habit');
      }
    } catch (error) {
      console.error('Error adding habit:', error);
      alert('❌ Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  // DELETE - Hapus habit
  const deleteHabit = async (id: number) => {
    if (!confirm('Apakah Anda yakin ingin menghapus habit ini?')) {
      return;
    }

    try {
      const response = await fetch(`/api/habits/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchHabits(); // Refresh list
        alert('✅ Habit berhasil dihapus!');
      } else {
        alert('❌ Gagal menghapus habit');
      }
    } catch (error) {
      console.error('Error deleting habit:', error);
      alert('❌ Terjadi kesalahan');
    }
  };

  // EDIT - Buka modal edit
  const openEditModal = (habit: Habit) => {
    setEditHabit(habit);
    setEditName(habit.name);
    setEditDescription(habit.description || '');
    setShowEditModal(true);
  };

  // UPDATE - Simpan perubahan edit
  const saveEdit = async () => {
    if (!editHabit || editName.trim() === '') {
      alert('Nama habit tidak boleh kosong!');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/habits/${editHabit.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName,
          description: editDescription,
        })
      });

      if (response.ok) {
        setShowEditModal(false);
        fetchHabits(); // Refresh list
        alert('✅ Habit berhasil diupdate!');
      } else {
        alert('❌ Gagal mengupdate habit');
      }
    } catch (error) {
      console.error('Error updating habit:', error);
      alert('❌ Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  const getCardColor = (index: number) => {
    const colors = ['card-pink', 'card-purple', 'card-yellow', 'card-blue'];
    return colors[index % colors.length];
  };

  const totalHabits = habits.length;
  const totalCompletedDays = habits.reduce((sum, habit) => sum + habit.completedDays, 0);
  const avgCompletedDays = totalHabits > 0 ? Math.round(totalCompletedDays / totalHabits) : 0;

  return (
    <Container fluid className="p-4">
      <Row className="mb-4">
        <Col>
          <div className="d-flex align-items-center">
            <i className="bi bi-stars text-pink me-3" style={{ fontSize: '48px' }}></i>
            <div>
              <h1 className="text-pink fw-bold mb-1">My Habit Dashboard</h1>
              <p className="text-muted mb-0">Kelola dan track semua habit kamu di sini!</p>
            </div>
          </div>
        </Col>
      </Row>

      <Row className="mb-4">
        <Col lg={4} md={6} className="mb-3">
          <div className="stat-card d-flex flex-column align-items-center justify-content-center" style={{ borderRadius: '15px', background: 'linear-gradient(135deg, #FF69B4 0%, #FF1493 100%)' }}>
            <i className="bi bi-heart-fill" style={{ fontSize: '40px' }}></i>
            <div className="stat-number">{totalHabits}</div>
            <div>Total Habits</div>
          </div>
        </Col>
        <Col lg={4} md={6} className="mb-3">
          <div className="stat-card d-flex flex-column align-items-center justify-content-center" style={{ borderRadius: '15px', background: 'linear-gradient(135deg, #C77DFF 0%, #9D4EDD 100%)' }}>
            <i className="bi bi-calendar-check-fill" style={{ fontSize: '40px' }}></i>
            <div className="stat-number">{totalCompletedDays}</div>
            <div>Days Completed</div>
          </div>
        </Col>
        <Col lg={4} md={6} className="mb-3">
          <div className="stat-card d-flex flex-column align-items-center justify-content-center" style={{ borderRadius: '15px', background: 'linear-gradient(135deg, #FFD98E 0%, #FFC857 100%)' }}>
            <i className="bi bi-trophy-fill" style={{ fontSize: '40px' }}></i>
            <div className="stat-number">{avgCompletedDays}</div>
            <div>Average Streak</div>
          </div>
        </Col>
      </Row>

      <Row>
        <Col lg={5} className="mb-4">
          <Card className="card-pink border-0 shadow-lg" style={{ borderRadius: '25px' }}>
            <Card.Body className="p-4">
              <div className="d-flex align-items-center mb-4">
                <div style={{ 
                  width: '50px', 
                  height: '50px', 
                  borderRadius: '15px',
                  background: 'linear-gradient(135deg, #FF69B4 0%, #FF1493 100%)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: '15px'
                }}>
                  <i className="bi bi-plus-lg text-white" style={{ fontSize: '24px' }}></i>
                </div>
                <div>
                  <h4 className="text-pink fw-bold mb-0">Tambah Habit Baru</h4>
                  <small className="text-muted">Buat habit baru untuk dicapai</small>
                </div>
              </div>
              
              <Form>
                <Form.Group className="mb-3">
                  <Form.Label className="fw-bold text-pink">
                    <i className="bi bi-tag-fill me-2"></i>
                    Nama Habit
                  </Form.Label>
                  <Form.Control
                    type="text"
                    size="lg"
                    placeholder="Contoh: Olahraga pagi"
                    value={newHabitName}
                    onChange={(e) => setNewHabitName(e.target.value)}
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label className="fw-bold text-pink">
                    <i className="bi bi-text-paragraph me-2"></i>
                    Deskripsi
                  </Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    placeholder="Ceritakan tentang habit ini..."
                    value={newHabitDescription}
                    onChange={(e) => setNewHabitDescription(e.target.value)}
                  />
                </Form.Group>
              </Form>
              
              <Button 
                size="lg" 
                className="btn-pink w-100" 
                onClick={addHabit}
                disabled={loading}
              >
                <i className="bi bi-plus-circle-fill me-2"></i>
                {loading ? 'Menyimpan...' : 'Tambah Habit'}
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={7}>
          <div className="mb-3">
            <h4 className="text-pink fw-bold">
              <i className="bi bi-list-ul me-2"></i>
              Daftar Habits ({habits.length})
            </h4>
          </div>

          {habits.length === 0 ? (
            <Alert className="card-purple border-0 shadow" style={{ borderRadius: '20px' }}>
              <div className="text-center p-4">
                <i className="bi bi-inbox" style={{ fontSize: '64px', color: '#C77DFF' }}></i>
                <h5 className="mt-3 mb-2" style={{ color: '#9D4EDD' }}>Belum Ada Habit</h5>
                <p className="mb-0 text-muted">Mulai tambahkan habit pertama kamu menggunakan form di sebelah kiri!</p>
              </div>
            </Alert>
          ) : (
            <Row>
              {habits.map((habit, index) => (
                <Col key={habit.id} md={6} className="mb-3">
                  <Card className={`${getCardColor(index)} border-0 shadow h-100`}>
                    <Card.Body className="p-4">
                      <div className="d-flex justify-content-between align-items-start mb-3">
                        <h5 className="text-pink fw-bold mb-0">{habit.name}</h5>
                      </div>
                      
                      <p className="text-muted mb-3" style={{ fontSize: '14px' }}>
                        {habit.description || 'Tidak ada deskripsi'}
                      </p>

                      <div className="d-flex align-items-center mb-3 p-2 rounded" style={{ background: 'rgba(255,255,255,0.5)' }}>
                        <i className="bi bi-fire text-danger me-2" style={{ fontSize: '20px' }}></i>
                        <div>
                          <small className="text-muted d-block" style={{ fontSize: '11px' }}>Streak</small>
                          <strong style={{ fontSize: '16px', color: '#FF1493' }}>{habit.completedDays} hari</strong>
                        </div>
                      </div>

                      <div className="d-grid gap-2">
                        <Link href={`/habits/${habit.id}`}>
                          <Button 
                            variant="outline-primary" 
                            size="sm" 
                            className="w-100"
                            style={{ borderRadius: '15px', borderColor: '#FF69B4', color: '#FF1493' }}
                          >
                            <i className="bi bi-eye-fill me-2"></i>
                            Lihat Detail
                          </Button>
                        </Link>
                        <Button
                          variant="outline-warning"
                          size="sm"
                          className="w-100"
                          onClick={() => openEditModal(habit)}
                          style={{ borderRadius: '15px', borderColor: '#FFD98E', color: '#D4A04C' }}
                        >
                          <i className="bi bi-pencil-fill me-2"></i>
                          Edit
                        </Button>
                        <Button
                          variant="outline-danger"
                          size="sm"
                          onClick={() => deleteHabit(habit.id)}
                          style={{ borderRadius: '15px', borderColor: '#FF69B4', color: '#FF1493' }}
                        >
                          <i className="bi bi-trash-fill me-2"></i>
                          Hapus
                        </Button>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          )}
        </Col>
      </Row>

      {/* Modal Edit */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)} centered>
        <Modal.Header closeButton style={{ background: '#FFF0F5', borderBottom: '2px solid #FFB6D9' }}>
          <Modal.Title className="text-pink fw-bold">
            <i className="bi bi-pencil-square me-2"></i>
            Edit Habit
          </Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ background: '#FFF0F5' }}>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label className="fw-bold text-pink">
                <i className="bi bi-tag-fill me-2"></i>
                Nama Habit
              </Form.Label>
              <Form.Control
                type="text"
                size="lg"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label className="fw-bold text-pink">
                <i className="bi bi-text-paragraph me-2"></i>
                Deskripsi
              </Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer style={{ background: '#FFF0F5', borderTop: '2px solid #FFB6D9' }}>
          <Button 
            variant="secondary" 
            onClick={() => setShowEditModal(false)}
            style={{ borderRadius: '15px' }}
          >
            Batal
          </Button>
          <Button 
            className="btn-pink" 
            onClick={saveEdit} 
            disabled={loading}
            style={{ borderRadius: '15px' }}
          >
            <i className="bi bi-check-circle-fill me-2"></i>
            {loading ? 'Menyimpan...' : 'Simpan Perubahan'}
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}