'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import {
  Container,
  Row,
  Col,
  Card,
  Button,
  Alert,
  Badge,
  Table,
} from 'react-bootstrap';

interface Habit {
  id: number;
  name: string;
  description: string;
  createdAt: string;
  completedDays: number;
}

export default function HabitDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params?.id;

  const [habit, setHabit] = useState<Habit | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;

    const fetchHabit = async () => {
      setLoading(true);
      setError(null);
      setNotFound(false);

      try {
        const res = await fetch(`/api/habits/${id}`);

        if (res.status === 404) {
          setNotFound(true);
          return;
        }

        if (!res.ok) {
          throw new Error('Gagal mengambil data habit');
        }

        const data: Habit = await res.json();
        setHabit(data);
      } catch (err: any) {
        console.error(err);
        setError(err.message || 'Terjadi kesalahan');
      } finally {
        setLoading(false);
      }
    };

    fetchHabit();
  }, [id]);

  if (loading) {
    return (
      <Container fluid className="p-4">
        <p>Memuat data habit...</p>
      </Container>
    );
  }

  if (notFound || !habit) {
    return (
      <Container fluid className="p-4">
        <Row className="justify-content-center mt-5">
          <Col md={8}>
            <Card
              className="text-center"
              style={{
                borderRadius: '25px',
                border: 'none',
                background: '#FFD1E8',
                padding: '40px',
              }}
            >
              <Card.Body>
                <div
                  style={{
                    fontSize: '50px',
                    color: '#FF1493',
                    marginBottom: '20px',
                  }}
                >
                  <i className="bi bi-exclamation-triangle-fill" />
                </div>
                <Card.Title
                  style={{
                    fontSize: '28px',
                    fontWeight: 700,
                    marginBottom: '10px',
                  }}
                >
                  Habit Tidak Ditemukan
                </Card.Title>
                <Card.Text style={{ fontSize: '16px', color: '#555' }}>
                  Habit dengan ID tersebut tidak ada di sistem.
                </Card.Text>
                <Link href="/habits">
                  <Button
                    style={{
                      marginTop: '20px',
                      padding: '12px 24px',
                      borderRadius: '30px',
                      backgroundColor: '#FF69B4',
                      border: 'none',
                      fontWeight: 'bold',
                    }}
                  >
                    ← Kembali ke Dashboard
                  </Button>
                </Link>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    );
  }

  return (
    <Container fluid className="p-4">
      <div className="mb-4">
        <Link href="/habits">
          <Button
            variant="outline-secondary"
            style={{
              borderRadius: '15px',
              borderColor: '#FFB6D9',
              color: '#FF1493',
            }}
          >
            <i className="bi bi-arrow-left me-2" />
            Kembali ke Dashboard
          </Button>
        </Link>
      </div>

      {error && (
        <Alert variant="danger" className="mb-4">
          {error}
        </Alert>
      )}

      <Row>
        <Col md={8}>
          <Card
            style={{
              borderRadius: '20px',
              border: 'none',
              boxShadow: '0 10px 20px rgba(0,0,0,0.05)',
            }}
          >
            <Card.Body>
              <div className="d-flex justify-content-between align-items-start mb-3">
                <div>
                  <Card.Title
                    style={{ fontSize: '26px', fontWeight: 'bold' }}
                  >
                    {habit.name}
                  </Card.Title>
                  <Card.Subtitle style={{ color: '#888' }}>
                    Dibuat pada{' '}
                    {new Date(habit.createdAt).toLocaleDateString('id-ID', {
                      day: '2-digit',
                      month: 'long',
                      year: 'numeric',
                    })}
                  </Card.Subtitle>
                </div>

                <Badge
                  bg="info"
                  pill
                  style={{
                    fontSize: '14px',
                    padding: '8px 14px',
                    backgroundColor: '#FFB6D9',
                    color: '#880E4F',
                  }}
                >
                  {habit.completedDays} hari tercapai
                </Badge>
              </div>

              <Card.Text style={{ fontSize: '16px', marginTop: '15px' }}>
                {habit.description || (
                  <span style={{ color: '#999' }}>
                    Tidak ada deskripsi.
                  </span>
                )}
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card
            style={{
              borderRadius: '20px',
              border: 'none',
              boxShadow: '0 10px 20px rgba(0,0,0,0.05)',
            }}
          >
            <Card.Body>
              <Card.Title
                style={{ fontWeight: 'bold', marginBottom: '15px' }}
              >
                Progress Singkat
              </Card.Title>
              <Table borderless responsive>
                <tbody>
                  <tr>
                    <td>Total hari tercapai</td>
                    <td className="text-end">
                      <strong>{habit.completedDays}</strong>
                    </td>
                  </tr>
                  {/* Bisa tambahkan data lain di sini */}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}
