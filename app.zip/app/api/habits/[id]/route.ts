// app/api/habits/[id]/route.ts
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

interface RouteParams {
  params: { id: string };
}

// Helper parse ID
function parseId(params: RouteParams['params']) {
  const id = Number(params.id);
  if (Number.isNaN(id)) {
    throw new Error('Invalid ID');
  }
  return id;
}

// GET /api/habits/:id
export async function GET(req: Request, { params }: RouteParams) {
  try {
    const id = parseId(params);

    const habit = await prisma.habit.findUnique({
      where: { id },
    });

    if (!habit) {
      return NextResponse.json({ error: 'Habit not found' }, { status: 404 });
    }

    return NextResponse.json(habit, { status: 200 });
  } catch (error) {
    console.error('GET /api/habits/[id] error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch habit' },
      { status: 500 },
    );
  }
}

// PUT /api/habits/:id -> update name/description
export async function PUT(req: Request, { params }: RouteParams) {
  try {
    const id = parseId(params);
    const body = await req.json();
    const { name, description } = body;

    if (!name || typeof name !== 'string') {
      return NextResponse.json(
        { error: 'Name is required' },
        { status: 400 },
      );
    }

    const habit = await prisma.habit.update({
      where: { id },
      data: {
        name,
        description: description || '',
      },
    });

    return NextResponse.json(habit, { status: 200 });
  } catch (error: any) {
    console.error('PUT /api/habits/[id] error:', error);
    if (error?.code === 'P2025') {
      // Prisma record not found
      return NextResponse.json(
        { error: 'Habit not found' },
        { status: 404 },
      );
    }
    return NextResponse.json(
      { error: 'Failed to update habit' },
      { status: 500 },
    );
  }
}

// DELETE /api/habits/:id
export async function DELETE(req: Request, { params }: RouteParams) {
  try {
    const id = parseId(params);

    await prisma.habit.delete({
      where: { id },
    });

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error: any) {
    console.error('DELETE /api/habits/[id] error:', error);
    if (error?.code === 'P2025') {
      return NextResponse.json(
        { error: 'Habit not found' },
        { status: 404 },
      );
    }
    return NextResponse.json(
      { error: 'Failed to delete habit' },
      { status: 500 },
    );
  }
}
